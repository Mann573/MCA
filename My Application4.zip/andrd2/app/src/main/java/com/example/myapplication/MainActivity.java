package com.example.myapplication;

import android.app.DatePickerDialog;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.*;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.time.LocalDate;
import java.time.Period;
import java.util.Calendar;
import java.util.Date;

import android.content.Intent;
public class MainActivity extends AppCompatActivity {

    EditText name,email,pwd,confpwd,phoneno,Dob;

    Button  btnSubmit;

//    TextView tvDOB;

    Spinner spTracks;
    RadioGroup track;

//    date c;

    @Override
    protected void onCreate(Bundle savedInstanceState) {




        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        init();
        clickListeners();
    }

    public void init()
    {
        setContentView(R.layout.activity_main);
        name = findViewById(R.id.inpname);
        email = findViewById(R.id.intemail);
        pwd= findViewById(R.id.passwd);
        confpwd=findViewById(R.id.confirmpass);
        phoneno= findViewById(R.id.phone);
        Dob = findViewById(R.id.dob);
        btnSubmit= findViewById(R.id.btnsubmit);

//         tvDOB= findViewById(R.id.phone);

         track = findViewById(R.id.genradgroup);

    }

    private int getage(int year,int month,int day)
    {
        return Period.between(LocalDate.of(year, month, day),LocalDate.now()).getYears();
    }

    private void clickListeners()
    {
//        track.setOnClickListener(new RadioGroup.OnCheckedChangeListener()
//        {
//            @Override
//            public void OnClickListenerRadioGroup group,int checkedId){
//                if (checkedId == R.id.male) {
//                    Toast.makeText(MainActivity.this, "Male", Toast.LENGTH_SHORT).show();
//                } else if (checkedId == R.id.female) {
//                    Toast.makeText(MainActivity.this, "Female", Toast.LENGTH_SHORT).show();
//                }
//
//            }
//        });

        Dob.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Calendar c =Calendar.getInstance();
                int year = c.get(Calendar.YEAR);
                int month = c.get(Calendar.MONTH);
                int day = c.get(Calendar.DAY_OF_MONTH);

                DatePickerDialog pickerDialog = new
                        DatePickerDialog(MainActivity.this, new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                        int age = getage(year,month+1,dayOfMonth);
                        Dob.setText("Age: "+age+" years");
                    }
                },year,month,day);
                pickerDialog.getDatePicker().setMaxDate(new Date().getTime());
//                pickerDialog.getDatePicker().setMaxDate(local);
                pickerDialog.show();

            }
        });

//        spTracks.

        btnSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {



                String ename,eemail,epwd,ecpwd,epno;
                ename = name.getText().toString();
                eemail = email.getText().toString();
                epwd= pwd.getText().toString();
                ecpwd= confpwd.getText().toString();
                epno= phoneno.getText().toString();




                if (ename.isEmpty()) {
                    Toast.makeText(MainActivity.this, "Please Enter Name", Toast.LENGTH_SHORT).show();
                }
                else if (epno.isEmpty()) {
                    Toast.makeText(MainActivity.this, "Please Enter phone number", Toast.LENGTH_SHORT).show();
                }
                else if (eemail.isEmpty()) {
                    Toast.makeText(MainActivity.this, "Please Enter Email", Toast.LENGTH_SHORT).show();
                }
                else if (epwd.isEmpty()) {
                    Toast.makeText(MainActivity.this, "Please Enter Password", Toast.LENGTH_SHORT).show();
                }
                else if (ecpwd.isEmpty()) {
                    Toast.makeText(MainActivity.this, "Please Confirm Password", Toast.LENGTH_SHORT).show();
                }
                else if (!ecpwd.equals(epwd)) {
                    Toast.makeText(MainActivity.this, "Confirm Paasword is not same as Password", Toast.LENGTH_SHORT).show();
                }


                else  {
//                    String hobby;

                    Toast.makeText(MainActivity.this, "Form Submitted", Toast.LENGTH_SHORT).show();

                    Intent i = new Intent(MainActivity.this,HomeActivity.class);
                    Bundle b = new Bundle();
                    b.putString("name",ename);
                    b.putString("email",eemail);
                    b.putString("phoneNo",epno);
                    i.putExtras(b);
                    startActivity(i);
                }
            }
        });

    }
    }
