package com.example.firstapp;

import android.os.Bundle;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.fragment.app.Fragment;
import androidx.core.content.ContextCompat;
import android.content.pm.PackageManager;
import android.Manifest;
import android.widget.Toast;

public class EmployeeActivity extends AppCompatActivity {

    private static int  CAMERA_REQUEST_CODE=100;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
//        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_employee);
        EmployeeRegister employeeRegister = new com.example.firstapp.EmployeeRegister();
//        EmployeeRegisterTwo employeeRegisterTwo = new com.example.firstapp.EmployeeRegisterTwo(new Employee());

        loadFragment(new EmployeeRegister());
    }

    public void loadFragment(Fragment fragment) {
        getSupportFragmentManager()
                .beginTransaction()
                .replace(R.id.employeeContainer, fragment)
                .commit();
    }

    public void checkPermission() {
        if(ContextCompat.checkSelfPermission(this,Manifest.permission.CAMERA) == PackageManager.PERMISSION_DENIED) {
            androidx.core.app.ActivityCompat.requestPermissions(EmployeeActivity.this,new String[]{Manifest.permission.CAMERA},100);

        }
        else {
            android.widget.Toast.makeText(this,"Permission Granted", android.widget.Toast.LENGTH_LONG).show();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @androidx.annotation.NonNull String[] permissions, @androidx.annotation.NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if(requestCode == CAMERA_REQUEST_CODE) {
            if( (grantResults.length > 0) && (grantResults[0] == PackageManager.PERMISSION_GRANTED)) {
                Toast.makeText(this,"Permission Granted", android.widget.Toast.LENGTH_LONG).show();
            }
            else {
                Toast.makeText(this,"Permission Not Granted", android.widget.Toast.LENGTH_LONG).show();

            }
        }
    }
}