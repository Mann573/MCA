package com.rwgu.mca3;

import java.io.Serializable;
public class Employee {
    String fname,lname,phoneNo,emailid,age,gender,address,qualification,position,lastCompany,applyForPosition;

    double experience, exp_salary;

    public void setfname(String firstName)
    {
        this.fname = firstName;
    }
    public String getfname()
    {
    return this.fname;
    }
    public void setlname(String lastName)
    {
        this.lname = lastName;
    }
    public String getlname()
    {
        return this.lname;
    }
    public void setPhoneNo(String phoneNo)
    {
        this.phoneNo = phoneNo;
    }
    public String getphoneNo()
    {
        return this.phoneNo;
    }

    public void setemailid(String Emailid)
    {
        this.emailid = Emailid;
    }
    public String getemailid()
    {
        return this.emailid;
    }

    public void setage(String age)
    {
        this.age = age;
    }
    public String getage()
    {
        return this.age;
    }
    public void setgender(String gender)
    {
        this.gender = gender;
    }
    public String getgender()
    {
        return this.gender;
    }
    public void setaddress(String address)
    {
        this.address = address;
    }
    public String getaddress()
    {
        return this.address;
    }




}




