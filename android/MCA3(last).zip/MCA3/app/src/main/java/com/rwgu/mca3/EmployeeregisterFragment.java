package com.rwgu.mca3;

import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import com.google.android.material.textfield.TextInputLayout;
import android.widget.*;
//import com.rwgu.mca3.R.id.*;
/**

 * create an instance of this fragment.
 */
public class EmployeeregisterFragment extends Fragment {

    TextInputLayout wrpFirstName,wrpLastName,wrpemail,wrpphoneno,wrpaddr;
    android.widget.Spinner wrpspngender;

    Button btnage,btnnext;

    TextView wrptvAge,txtage;

    String gender;

    private EmployeeActivity employeeActivity;

    @Override
    public void onAttach(@androidx.annotation.NonNull android.content.Context context) {
        super.onAttach(context);
        employeeActivity = (EmployeeActivity) getActivity();
    }

    public EmployeeregisterFragment() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *@return A new instance of fragment EmployeeregisterFragment.
     */
    // TODO: Rename and change types and number of parameters


//    @Override
//    public void onCreate() {
//        super.onCreate(savedInstanceState);
//        if (getArguments() != null) {
//            mParam1 = getArguments().getString(ARG_PARAM1);
//            mParam2 = getArguments().getString(ARG_PARAM2);
//        }
//    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_employeeregister, container, false);
        // Inflate the layout for this fragment
        init(view);
        onTextChangeEventListener(wrpFirstName);
        onButtonClickListener();
        return view;
    }

    private void init(View view)
    {
        wrpFirstName = view.findViewById(R.id.wrpFirstName);
        wrpLastName = view.findViewById(R.id.wrpLastName);
        wrpemail = view.findViewById(R.id.wrpemail);
        wrpphoneno = view.findViewById(R.id.wrpphoneno);
        wrpaddr = view.findViewById(R.id.wrpaddr);
        btnnext = view.findViewById(R.id.btnnext);
        btnage = view.findViewById(R.id.btnage);
        txtage = view.findViewById(R.id.txtage);





    }

    private void onTextChangeEventListener(TextInputLayout textInputLayout) {
        EditText editText = textInputLayout.getEditText();
                editText.addTextChangedListener(new android.text.TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (editText.getText().toString().isEmpty()) {
                    textInputLayout.setError("Please Enter Valid Text");
                } else {
                    textInputLayout.setError("");
                }
            }

            @Override
            public void afterTextChanged(android.text.Editable s) {

            }
        });
    }

    private void onButtonClickListener() {
        btnage.setOnClickListener(v -> {

            java.util.Calendar c = java.util.Calendar.getInstance();
            int year = c.get(java.util.Calendar.YEAR);
            int month = c.get(java.util.Calendar.MONTH);
            int day = c.get(java.util.Calendar.DAY_OF_MONTH);

            android.app.DatePickerDialog pickerDialog = new android.app.DatePickerDialog(getContext(), new android.app.DatePickerDialog.OnDateSetListener() {
                @Override
                public void onDateSet(android.widget.DatePicker view, int year, int month, int dayOfMonth) {
                    int age = getAge(year,month,year);
                    txtage.setText("Age: "+age+" years");
                }
            },year,month,day);

            pickerDialog.getDatePicker().setMaxDate(new java.util.Date().getTime());
            pickerDialog.show();
        });

//        wrpspngender.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener() {
//            @Override
//            public void onItemSelected(android.widget.AdapterView<?> parent, android.view.View view, int position, long id) {
//                gender = parent.getItemAtPosition(position).toString();
//            }
//
//            @Override
//            public void onNothingSelected(android.widget.AdapterView<?> parent) {
//
//            }
//        });

        btnnext.setOnClickListener(v -> {
            String fname,lname,phoneNo,emailId,age,address;
            fname = getText(wrpFirstName);
        });

    }
    private int getAge(int year, int month, int day) {
        return java.time.Period.between(java.time.LocalDate.of(year, month, day), java.time.LocalDate.now()).getYears();
    }

    private String getText(TextInputLayout textInputLayout)
    {
        return textInputLayout.getEditText().toString();
    }

}