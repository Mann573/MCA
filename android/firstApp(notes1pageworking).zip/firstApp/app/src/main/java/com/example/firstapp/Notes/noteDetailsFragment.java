package com.example.firstapp.Notes;

import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import com.example.firstapp.R;
import com.example.firstapp.Notes.*;
import com.example.firstapp.EmployeeActivity;
import com.google.android.material.floatingactionbutton.ExtendedFloatingActionButton;

import androidx.recyclerview.widget.RecyclerView;


public class noteDetailsFragment extends Fragment {
    ExtendedFloatingActionButton fabaddnewnote;
    private EmployeeActivity employeeActivity;
    public static noteDetailsFragment newInstance(String param1, String param2) {
        noteDetailsFragment fragment = new noteDetailsFragment();
        Bundle args = new Bundle();

        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onAttach(@androidx.annotation.NonNull android.content.Context context) {
        super.onAttach(context);
        employeeActivity = (EmployeeActivity) getActivity();
    }


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_note_details, container, false);
        init(view);
        return view;
    }

    public void init(View view)
    {
        fabaddnewnote = view.findViewById(R.id.fabaddnewnote);
        onButtonClickListener();
    }
    private void onButtonClickListener() {
        fabaddnewnote.setOnClickListener(v -> {
            employeeActivity.loadFragment(new notesfragment());
        });
    }




}