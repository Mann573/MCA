package com.example.firstapp.Notes;
import android.database.sqlite.*;
import android.content.*;
import com.example.firstapp.Notes.*;
public class DatabaseHelper extends SQLiteOpenHelper {

    static final String db_name="notes.DB";
    static final int db_version = 1;

    public DatabaseHelper(Context context) {
        super(context,db_name,null,db_version);
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        sqLiteDatabase.execSQL(Notes.SQL_CREATE_ENTITY);

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL(Notes.SQL_DELETE_ENTITY);
        onCreate(db);
    }

    @Override
    public void onDowngrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        onUpgrade(db,oldVersion,newVersion);
    }
}
