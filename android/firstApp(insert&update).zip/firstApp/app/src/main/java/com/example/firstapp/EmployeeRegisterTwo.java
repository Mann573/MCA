package com.example.firstapp;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.LinearLayout;

import androidx.fragment.app.Fragment;

/**
 * A simple {@link Fragment} subclass.
 * create an instance of this fragment.
 */
public class EmployeeRegisterTwo extends Fragment {

    int item_count = 0;
    LinearLayout linearLayout;
    private Employee employee;


    public EmployeeRegisterTwo() {
        // Required empty public constructor
    }

    public EmployeeRegisterTwo(Employee employee) {
        this.employee = employee;
    }

    android.widget.Button btnApply;
    public void init(View view) {
        linearLayout = view.findViewById(R.id.llcompany);
        btnApply = view.findViewById(R.id.btnApply);

        btnApply.setOnClickListener(v->{
            employee.setQualification(gettextforallcompany());
        });
        addnewCompany();
    }

    private String gettextforallcompany()
    {
        StringBuilder allcompany = new StringBuilder();
        for (int i = 0; i < linearLayout.getChildCount(); i++) {
            View itemview = linearLayout.getChildAt(i);
            com.google.android.material.textfield.TextInputLayout textInputLayout = itemview.findViewById(R.id.lastcompany);

            String text = java.util.Objects.requireNonNull(textInputLayout.getEditText()).getText().toString();
            if(!text.isEmpty()) {
                allcompany.append(text).append(", ");

            }

        }
        return allcompany.toString().replaceAll(",(?!.*,)","");

    }

    public void addnewCompany() {
        View company = getLayoutInflater().inflate(R.layout.item_layout, linearLayout, false);
        ImageButton btnadd, btndel;
        btnadd = company.findViewById(R.id.btnadd);
        btndel = company.findViewById(R.id.btndel);

        btnadd.setOnClickListener(y -> {
            addnewCompany();
        });

        btndel.setOnClickListener(y -> {
            linearLayout.removeView(company);
            item_count--;
            updateitemvisibility();
        });

        linearLayout.addView(company);
        item_count++;
        updateitemvisibility();

    }

    private void updateitemvisibility() {
        for (int i = 0; i < linearLayout.getChildCount(); i++) {
            View itemview = linearLayout.getChildAt(i);
            ImageButton additembutton = itemview.findViewById(R.id.btnadd);
            ImageButton delitembutton = itemview.findViewById(R.id.btndel);
            additembutton.setVisibility(android.view.View.GONE);
            delitembutton.setVisibility(android.view.View.VISIBLE);
        }
        if (item_count > 0) {
            View lastitemview = linearLayout.getChildAt(linearLayout.getChildCount() - 1);
            ImageButton lastadditembutton = lastitemview.findViewById(R.id.btnadd);
            lastadditembutton.setVisibility(android.view.View.VISIBLE);
        }

        if (item_count == 0) {
            View lastitemview = linearLayout.getChildAt(linearLayout.getChildCount() - 1);
            ImageButton lastdelitembutton = lastitemview.findViewById(R.id.btndel);
            lastdelitembutton.setVisibility(android.view.View.GONE);
        }
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_employee_register_two, container, false);
        // Inflate the layout for this fragment
        init(view);
        return view;
    }
}