package com.example.firstapp.Notes;
import android.content.Context;
import android.database.sqlite.*;
import java.sql.*;
import java.util.ArrayList;

import com.example.firstapp.Notes.*;
public class DBmanager {
    private final android.content.Context context;
    private com.example.firstapp.Notes.DatabaseHelper databaseHelper;
    private android.database.sqlite.SQLiteDatabase sqLiteDatabase;

    public DBmanager(Context context) {
        this.context = context;
    }

    //To open Database
    public void openDB() throws SQLException {
        databaseHelper = new DatabaseHelper(context);

        sqLiteDatabase = databaseHelper.getWritableDatabase();

    }

    //To Close Database
    public void closeDB() {
        databaseHelper.close();
    }

    public long insert(Notes notes) {
        android.content.ContentValues contentValues = new android.content.ContentValues();
        contentValues.put(Notes.c_notes_title,notes.getNotetitle());
        contentValues.put(com.example.firstapp.Notes.Notes.c_notes_description,notes.getNotedetails());
        return sqLiteDatabase.insert(notes.TABLENAME,null,contentValues);

    }

    public ArrayList<Notes> getAllNotes() {
        ArrayList<Notes> noteslist = new ArrayList<>();
        android.database.Cursor cursor = sqLiteDatabase.rawQuery("SELECT * from "+ Notes.TABLENAME,null);
        while(cursor.moveToNext()) {
            int id = cursor.getInt(0);
            String title = cursor.getString(1);
            String desc = cursor.getString(2);
            Notes note = new Notes();
            note.setId(id);
            note.setNotetitle(title);
            note.setNotedetails(desc);
            noteslist.add(note);
        }
        return noteslist;
    }

    public long update(Notes notes) {
        android.content.ContentValues contentValues = new android.content.ContentValues();
        contentValues.put(Notes.c_notes_title,notes.getNotetitle());
        contentValues.put(Notes.c_notes_description,notes.getNotedetails());
        return sqLiteDatabase.update(notes.TABLENAME,null, Notes.c_notes_id+"="+notes.getId(),null);
    }

    public long delete(Notes notes) {
        return sqLiteDatabase.delete(notes.TABLENAME, Notes.c_notes_id+"="+notes.getId(),null);
    }

}
