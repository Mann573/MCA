package com.example.firstapp.Notes;

import android.app.Activity;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.RecyclerView;

import com.example.firstapp.R;
import com.google.android.material.floatingactionbutton.ExtendedFloatingActionButton;

import java.util.ArrayList;


public class noteDetailsFragment extends Fragment implements com.example.firstapp.Notes.NoteitemInterface {
    ExtendedFloatingActionButton fabaddnewnote;
    private notesActivity notesActivity;
    NoteAdapter adapter;
    public static noteDetailsFragment newInstance(String param1, String param2) {
        noteDetailsFragment fragment = new noteDetailsFragment();
        Bundle args = new Bundle();
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onAttach(@androidx.annotation.NonNull Activity activity) {
        super.onAttach(activity);
        notesActivity = (notesActivity) getActivity();
    }


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_note_details, container, false);
        init(view);
        onButtonClickListener();
        RecyclerView recyclerView = view.findViewById(com.example.firstapp.R.id.rclnotes);
        adapter = new NoteAdapter(this);
        adapter.setNotes(notesActivity.dBmanager.getAllNotes());
        recyclerView.setAdapter(adapter);
        return view;
    }

    public void init(View view) {
        fabaddnewnote = view.findViewById(R.id.fabaddnewnote);
        onButtonClickListener();
    }

    private void onButtonClickListener() {
        fabaddnewnote.setOnClickListener(v -> {
            notesActivity.loadFragment(new notesfragment());
        });
    }

    private ArrayList<Notes> getNotes() {
        ArrayList<Notes> notes = new ArrayList<Notes>();
        notes.add(new com.example.firstapp.Notes.Notes("Text 1", "Description 1"));
        notes.add(new com.example.firstapp.Notes.Notes("Text 2", "Description 2"));
        notes.add(new com.example.firstapp.Notes.Notes("Text 3", "Description 3"));
        notes.add(new com.example.firstapp.Notes.Notes("Text 4", "Description 4"));
        return notes;
    }


    //Display a message when a note item is clicked
    @Override
    public void onItemClickListener(Notes notes) {
        notesfragment notesfragment = new notesfragment(notes);
        getParentFragmentManager()
                .beginTransaction()
                .replace(com.example.firstapp.R.id.notesContainer, notesfragment).addToBackStack(null)
                .commit();


    }

    @Override
    public void onItemLongClickListener(Notes notes) {
        new android.app.AlertDialog.Builder(getContext())
                .setTitle(notes.getNotetitle())
                .setMessage("Delete the Note")
                .setPositiveButton("Delete", new android.content.DialogInterface.OnClickListener() {
            @Override
            public void onClick(android.content.DialogInterface dialog, int which) {
                notesActivity.dBmanager.delete(notes);
                adapter.setNotes(notesActivity.dBmanager.getAllNotes());
            }
        })
                .setNegativeButton("Cancel",null)
                .show();

    }
}