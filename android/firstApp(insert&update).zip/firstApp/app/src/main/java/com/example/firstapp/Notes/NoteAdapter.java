package com.example.firstapp.Notes;

import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
public class NoteAdapter extends RecyclerView.Adapter<NoteViewHolder> {
    private java.util.ArrayList<Notes> notes = new java.util.ArrayList<>();
    private final NoteitemInterface noteitemInterface;

    public NoteAdapter(com.example.firstapp.Notes.NoteitemInterface noteitemInterface) {
        this.noteitemInterface = noteitemInterface;
    }

    @androidx.annotation.NonNull
    @Override
    public com.example.firstapp.Notes.NoteViewHolder onCreateViewHolder(@androidx.annotation.NonNull android.view.ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(parent.getContext());
        View v = inflater.inflate(com.example.firstapp.R.layout.itemnotes,parent,false);
        NoteViewHolder viewHolder = new com.example.firstapp.Notes.NoteViewHolder(v);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(@androidx.annotation.NonNull com.example.firstapp.Notes.NoteViewHolder holder, int position) {
        Notes note = notes.get(position);
        holder.tvtitle.setText(note.getNotetitle());
        holder.tvdesc.setText(note.getNotedetails());

        //For a click on each note
        holder.cvitem.setOnClickListener(new android.view.View.OnClickListener() {
            @Override
            public void onClick(android.view.View v) {
                noteitemInterface.onItemClickListener(note);
            }
        });

        //For a Long-click on each note
        holder.cvitem.setOnLongClickListener(v -> {
            noteitemInterface.onItemLongClickListener(note);
            return false;
        });

    }

    @Override
    public int getItemCount() {
        return notes.size();
    }
    public void setNotes(java.util.ArrayList<Notes> noteslist) {
        notes.clear();
        notes.addAll(noteslist);
        notifyDataSetChanged();
    }
}
