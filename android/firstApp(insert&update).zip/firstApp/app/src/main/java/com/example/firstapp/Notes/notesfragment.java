package com.example.firstapp.Notes;

import android.os.Bundle;
import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import com.example.firstapp.R;
import com.google.android.material.textfield.TextInputLayout;
/**
 * A simple {@link Fragment} subclass.
 * Use the {@link notesfragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class notesfragment extends Fragment {
    Button btngetback;
    notesActivity notesActivity;
    public Notes note;


    public notesfragment() {
    }


    public notesfragment(Notes notes) {
        this.note=notes;
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment notesfragment.
     */
    // TODO: Rename and change types and number of parameters
    public static notesfragment newInstance(String param1, String param2) {
        notesfragment fragment = new notesfragment();

        return fragment;
    }

    @Override
    public void onAttach(@NonNull Activity activity) {
        super.onAttach(activity);
        notesActivity = (notesActivity) getActivity();
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_notesfragment, container, false);
        init(view);
        return view;
    }

    public void init(View view)
    {
        TextInputLayout title = view.findViewById(R.id.inptitle);
        TextInputLayout desc = view.findViewById(R.id.inpdesc);
        btngetback = view.findViewById(R.id.btngetback);
        onButtonClickListener(title,desc);
    }

    public void onButtonClickListener(TextInputLayout title, TextInputLayout desc) {

        btngetback.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Notes notes = new Notes();

//                notes.setNotetitle(title.getEditText().getText().toString());
//                notes.setNotedetails(desc.getEditText().getText().toString());
//                String s1 = notes.getNotetitle();
//                String s2 = notes.getNotedetails();

                String s1= title.getEditText().getText().toString();
                String s2= desc.getEditText().getText().toString();
                Notes newnote = new Notes(s1,s2);
                long id = notesActivity.dBmanager.insert(newnote);
                android.util.Log.e("TAG", "onItemClickListener: "+id );
                getActivity().getSupportFragmentManager().popBackStack();
            }
        });
    }


}