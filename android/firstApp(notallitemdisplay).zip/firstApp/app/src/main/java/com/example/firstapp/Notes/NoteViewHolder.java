package com.example.firstapp.Notes;
import androidx.recyclerview.widget.RecyclerView;
import com.example.firstapp.R.*;
public class NoteViewHolder extends RecyclerView.ViewHolder {
    android.widget.TextView tvtitle,tvdesc;

    public NoteViewHolder(@androidx.annotation.NonNull android.view.View itemView) {
        super(itemView);
        tvtitle=itemView.findViewById(com.example.firstapp.R.id.tvnotestitle);
        tvdesc=itemView.findViewById(com.example.firstapp.R.id.tvnotesdesc);
    }

}
