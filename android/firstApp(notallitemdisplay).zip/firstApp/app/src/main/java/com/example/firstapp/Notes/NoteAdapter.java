package com.example.firstapp.Notes;

import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
public class NoteAdapter extends RecyclerView.Adapter<NoteViewHolder> {
    private java.util.ArrayList<Notes> notes = new java.util.ArrayList<>();

    @androidx.annotation.NonNull
    @Override
    public com.example.firstapp.Notes.NoteViewHolder onCreateViewHolder(@androidx.annotation.NonNull android.view.ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(parent.getContext());
        View v = inflater.inflate(com.example.firstapp.R.layout.itemnotes,parent,false);
        NoteViewHolder viewHolder = new com.example.firstapp.Notes.NoteViewHolder(v);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(@androidx.annotation.NonNull com.example.firstapp.Notes.NoteViewHolder holder, int position) {
        Notes note = notes.get(position);
        android.util.Log.d("Tag","Notes: "+note.getNotetitle());
        holder.tvtitle.setText(note.getNotetitle());
        holder.tvdesc.setText(note.getNotedetails());
    }

    @Override
    public int getItemCount() {
        return notes.size();
    }
    public void setNotes(java.util.ArrayList<Notes> noteslist) {
        notes.clear();
        notes.addAll(noteslist);
        notifyDataSetChanged();
    }
}
