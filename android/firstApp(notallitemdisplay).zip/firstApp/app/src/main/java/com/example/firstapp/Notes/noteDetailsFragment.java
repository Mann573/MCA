package com.example.firstapp.Notes;

import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import com.example.firstapp.R;
import com.example.firstapp.Notes.*;
import com.example.firstapp.EmployeeActivity;
import com.example.firstapp.Notes.notesActivity;
import com.google.android.material.floatingactionbutton.ExtendedFloatingActionButton;
import java.util.ArrayList;
import androidx.recyclerview.widget.RecyclerView;


public class noteDetailsFragment extends Fragment {
    ExtendedFloatingActionButton fabaddnewnote;
    private notesActivity ntsActivity;
    public static noteDetailsFragment newInstance(String param1, String param2) {
        noteDetailsFragment fragment = new noteDetailsFragment();
        Bundle args = new Bundle();

        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onAttach(@androidx.annotation.NonNull android.content.Context context) {
        super.onAttach(context);
        ntsActivity = (notesActivity) getActivity();
    }


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_note_details, container, false);
        init(view);
        onButtonClickListener();
        RecyclerView recyclerView = view.findViewById(com.example.firstapp.R.id.rclnotes);
        NoteAdapter adapter = new com.example.firstapp.Notes.NoteAdapter();
        adapter.setNotes(getNotes());
        recyclerView.setAdapter(adapter);

        return view;
    }

    public void init(View view)
    {
        fabaddnewnote = view.findViewById(R.id.fabaddnewnote);
        onButtonClickListener();
    }
    private void onButtonClickListener() {
        fabaddnewnote.setOnClickListener(v -> {
            ntsActivity.loadFragment(new notesfragment());
        });
    }

    private ArrayList<Notes> getNotes() {
        ArrayList<Notes> notes = new ArrayList<Notes>();
        notes.add(new com.example.firstapp.Notes.Notes("Text 1","Description 1"));
        notes.add(new com.example.firstapp.Notes.Notes("Text 2","Description 2"));
        notes.add(new com.example.firstapp.Notes.Notes("Text 3","Description 3"));
        notes.add(new com.example.firstapp.Notes.Notes("Text 4","Description 4"));
        return notes;
    }


}