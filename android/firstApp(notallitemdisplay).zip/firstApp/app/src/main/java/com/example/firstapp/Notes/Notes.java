package com.example.firstapp.Notes;
import java.io.Serializable;
public class Notes implements Serializable {
    String notetitle,notedetails;

    public Notes()
    {

    }
    public Notes(String notetitle, String notedetails) {
        this.notetitle = notetitle;
        this.notedetails = notedetails;
    }

    public String getNotetitle() {
        return notetitle;
    }

    public void setNotetitle(String notetitle) {
        this.notetitle = notetitle;
    }

    public String getNotedetails() {
        return notedetails;
    }

    public void setNotedetails(String notedetails) {
        this.notedetails = notedetails;
    }
}
