package com.example.firstapp.Notes;
import java.io.Serializable;
public class Notes implements Serializable {
    String notetitle,notedetails;

    //c=column names for each input a field is created "ID" is for sql
    public static final String TABLENAME = "notes";
    public static final String c_notes_id="note_id";
    public static final String c_notes_title="note_title";
    public static final String c_notes_description="note_description";
    public static final String SQL_CREATE_ENTITY="CREATE TABLE "+TABLENAME+" ("
            +c_notes_id+" INTEGER PRIMARY KEY,"
            +c_notes_title+" Text, "
            +c_notes_description+" TEXT)";
    public static final String SQL_DELETE_ENTITY="DROP TABLE IF EXISTS "+TABLENAME;



    public Notes()
    {

    }
    public Notes(String notetitle, String notedetails) {
        this.notetitle = notetitle;
        this.notedetails = notedetails;
    }

    public String getNotetitle() {
        return notetitle;
    }

    public void setNotetitle(String notetitle) {
        this.notetitle = notetitle;
    }

    public String getNotedetails() {
        return notedetails;
    }

    public void setNotedetails(String notedetails) {
        this.notedetails = notedetails;
    }
}
