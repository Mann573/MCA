package com.example.firstapp.Notes;
import androidx.recyclerview.widget.RecyclerView;
import com.example.firstapp.R.*;
import android.widget.*;
import androidx.cardview.widget.*;
public class NoteViewHolder extends RecyclerView.ViewHolder {
    android.widget.TextView tvtitle,tvdesc;
    androidx.cardview.widget.CardView cvitem;


    public NoteViewHolder(@androidx.annotation.NonNull android.view.View itemView) {
        super(itemView);
        tvtitle=itemView.findViewById(com.example.firstapp.R.id.tvnotestitle);
        tvdesc=itemView.findViewById(com.example.firstapp.R.id.tvnotesdesc);
        cvitem=itemView.findViewById(com.example.firstapp.R.id.cvnoteitem);
    }

}
