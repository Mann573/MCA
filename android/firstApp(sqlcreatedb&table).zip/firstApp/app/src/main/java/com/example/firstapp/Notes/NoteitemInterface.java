package com.example.firstapp.Notes;

public interface NoteitemInterface {
    void onItemClickListener(Notes notes);

    void onItemLongClickListener(Notes notes);
}
