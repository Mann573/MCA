package com.example.firstapp.Notes;
import android.content.Context;
import android.database.sqlite.*;
import java.sql.*;
public class DBmanager {
    private final android.content.Context context;
    private com.example.firstapp.Notes.DatabaseHelper databaseHelper;
    private android.database.sqlite.SQLiteDatabase sqLiteDatabase;

    public DBmanager(Context context) {
        this.context = context;
    }

    //To open Database
    public void openDB() throws SQLException {
        databaseHelper = new DatabaseHelper(context);

        sqLiteDatabase = databaseHelper.getWritableDatabase();

    }

    //To Close Database
    public void closeDB() {
        databaseHelper.close();
    }
}
